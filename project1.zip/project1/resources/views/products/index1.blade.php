@extends('products.layout')
 
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>User Registration </h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('products.create') }}"> Create New Product</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Password</th>
            <th>Action</th>
        </tr>
        @foreach ($products as $product)
        <tr>
            <td>{{ $product->name }}</td>
            <td>{{ $product->email }}</td>
            <td>{{ $product->password }}</td>
         
            <td>

                <form action="{{ route('products.destroy',$product->id) }}" method="POST">
   
                 
                    <div class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" ><i class="fa fa-pencil" aria-hidden="true"></i>Edit
                    </div>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
                @endforeach
            </td>
        </tr>
      
    </table>
  
  
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-id="{{$product->id}}" data-whatever1={{$product->name}} data-whatever2={{$product->email}} data-whatever3={{$product->password}} aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <label class="modal-title" for="exampleInputEmail1"  id="exampleModalLabel">User Edit</label>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
               
                
                <form action="{{ route('products.update',$product->id) }}" method="POST">
                   
                    @csrf
                    @method('PUT')
                     <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Name:</strong>
                                <input type="text" name="name" value="{{ $product->email }}"  class="form-control" placeholder="Name">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Email:</strong>
                                <input type="text" name="email" value="{{ $product->email }}" class="form-control" placeholder="Email">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Password:</strong>
                                <input type="text" name="password" value="{{ $product->password }}" class="form-control" placeholder="Password">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                          <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
               
                </form>
              
            
          </div>
        </div>
      </div>
      {!! $products->links() !!}
@endsection
<script>
$('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var id = button.data('whatever') // Extract info from data-* attributes
  var Name = button.data('whatever1') 
  var Email = button.data('whatever2')
  var Password = button.data('whatever3')
  var password = button.data('whatever')// Extract info from data-* attributeswhateverew
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + Name)
  // modal.find('.modal-body input').val(recipient)
  modal.find('.name').val(Name)
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + Email)
  // modal.find('.modal-body input').val(recipient)
  modal.find('.email').val(Email)
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + Password)
  // modal.find('.modal-body input').val(recipient)
  modal.find('.password').val(Password)
})
</script>