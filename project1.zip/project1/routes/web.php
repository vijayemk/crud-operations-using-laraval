<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FormValidtionController;
use App\Http\Controllers\TableditController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ImageUploadController;




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|S
*/

// Route::resource('products', 'FormValidtionController@index');
Route::any('/search', 'App\Http\Controllers\TableditController@index');

Route::get('tabledit', 'App\Http\Controllers\TableditController@index');
Route::get('/create', 'App\Http\Controllers\TableditController@create');
Route::post('/action', 'App\Http\Controllers\TableditController@actions');
Route::post('/register', 'App\Http\Controllers\TableditController@register');
Route::post('/otpvalid', 'App\Http\Controllers\TableditController@submitotp');
Route::post('/sendotp', 'App\Http\Controllers\TableditController@sendotp');
Route::post('/grocery/post', 'GroceryController@store');
Route::post('/delete', 'App\Http\Controllers\TableditController@delete');
Route::resource('products', FormValidtionController::class);


