<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous">
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"
        integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
    <title>
        Registration page
    </title>

</head>

<body class="linear-gradient-custom-2">
    <section class="vh-100 bg-image">
        <div class="mask d-flex align-items-center "  >
            <div class="container " style="margin-top: 150px; margin-bottom: 150px; ">
                <div class="row d-flex justify-content-center align-items-center " style="">
           
               
                
            
                    <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                        <div class="card" style="border-radius: 15px;">
                            <div class="card-body p-5">
                                <h2 class="text text-center mb-5">Create an account</h2>

                                    <?php if(session()->has('message')): ?>
                                   <div class="alert alert-success">
                                   <?php echo e(session()->get('message')); ?>

                                  </div>
                                  <?php endif; ?>
                                <form  method="POST" action="/register" is-invalid>
                                <?php echo csrf_field(); ?>
                               
                                <div class="form-outline mb-2">
                                    <label class="form-label" for="form3Example3cg">Name</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="name" id="name" placeholder="Name" value="<?php echo e(old('name')); ?>"  autocomplete="name"
                                        autofocus> 
                                   


                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <div class="form-outline mb-2">
                                    <label class="form-label" for="form3Example3cg">Email</label>
                                    <input type="email"  class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="email" id="email" placeholder="Email" value="<?php echo e(old('email')); ?>" 
                                        autocomplete="email" autofocus>
                                   
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-outline mb-2">
                                    <label class="form-label" for="form3Example3cg">Phoneno</label>
                                    <input type="text"  class="form-control  <?php $__errorArgs = ['phoneno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="phoneno" id="phoneno" placeholder="Phone No" value="<?php echo e(old('phoneno')); ?>" 
                                        autocomplete="phoneno" autofocus>
                                   
                                    <?php $__errorArgs = ['phoneno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-outline mb-2">
                                    <label class="form-label" for="form3Example3cg">Address1</label>

                                    <input type="text" class="form-control <?php $__errorArgs = ['address1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="address1" id="address1" placeholder="Address1" value="<?php echo e(old('address1')); ?>" 
                                        autocomplete="address1" autofocus>
                                    <?php $__errorArgs = ['address1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-outline mb-2">
                                    <label class="form-label" for="form3Example3cg">Address2</label>

                                    <input type="text" class="form-control <?php $__errorArgs = ['address2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="address2" id="address2" placeholder="Address2" value="<?php echo e(old('address2')); ?>" 
                                        autocomplete="address2" autofocus>
                                    <?php $__errorArgs = ['address2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-outline mb-2">
                                    <label class="form-label" for="form3Example3cg">Address3</label>

                                    <input type="text" class="form-control <?php $__errorArgs = ['address3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="address3" id="address3" placeholder="Address3" value="<?php echo e(old('address3')); ?>" 
                                        autocomplete="address3" autofocus>
                                    <?php $__errorArgs = ['address3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-outline mb-2">
                                    <label class="form-label" for="form3Example3cg">Pincode</label>

                                    <input type="pincode" class="form-control <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="pincode" id="pincode" placeholder="Pincode" value="<?php echo e(old('pincode')); ?>" 
                                        autocomplete="pincode" autofocus>
                                    <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-outline mb-2">
                                    <label class="form-label" for="form3Example3cg">Password</label>

                                    <input type="text" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="password" id="password" placeholder="Password" value="<?php echo e(old('password')); ?>" 
                                        autocomplete="password" >
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback" >
                                            <strong><?php echo e($message); ?></strong>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-check d-flex justify-content-center mb-5">
                                    <label class="form-check-label" for="form2Example3g">

                                    <input class="form-check-input me-2" type="checkbox" value=""
                                        id="form2Example3cg" />
                                        I agree all statements in <a href="#!" class="text-body"><u>Terms of
                                                service</u></a>
                                    </label>
                                </div>

                                <div class="d-flex justify-content-center">
                                     <button type="submit" id="register_form" class="btn btn-primary btn-round-lg btn-lg gradient-custom-4 text-body" style="margin-bottom: 20px; ">Register</button>
                                </div>
                                </form> 
                                   
                                        <div class="d-flex justify-content-center">
                                            <a class="Update" href=""><i class="ace-icon fa fa-pencil-square-o"></i>Forget Password</a>
                                        </div>
                                      
                                       
                                    
                                    <p class="text-center text-muted mt-5 mb-0">Have already an account?
                                   <a   href="" class="fw-bold text-body"><u>Login here</u></a></p>
                                  

                               
                            
                            </div>
                          
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </section>

  

    <div class="modal fade" id="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

           </div>

          

           <?php endif; ?>
        <form method="POST" id="myform" action="/otpvalid" is-invalid>
            <?php echo csrf_field(); ?>
            
            <div class="modal-header">
                <div class="d-flex justify-content-center">
              <h5 class="modal-title" id="exampleModalLabel">Forget Password</h5>
                </div>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="csrf" value="<?php echo e(Session::token()); ?>">
                <div class="mb-3">
                  
                  <input type="text" id="phoneno1" class="form-control" name="phoneno1" placeholder="Enter phoneno"  value="<?php echo e(old('phoneno1')); ?>" autocomplete="phoneno" autofocus>
                
                  <div id="phone_success" class="errors hidden">OTP send succesfully</div>
                  <div id="phone_error" class="error hidden">Please enter 10 digit valid phone number</div>
              </div>
             
            
                <div class="d-flex justify-content-end" >    
           
                <a  class="change" href="" ><i class="ace-icon fa fa-pencil-square-o"></i>change phoneno</a>
                </div>
                <div class="mb-3">
                    
                    <input type="hidden" id="otp" class="form-control <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="otp"   placeholder="Enter OTP" /required >
                 
                  <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback" >
                      <strong><?php echo e($message); ?></strong>
                  </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="modal-footer">
                <div class="d-flex justify-content-center">
              <button type="button" id="generateotp" onclick="myfunction()" class="btn btn-primary">generateotp</button>
                </div>
              <button type="submit" id="submitotp" class="btn btn-primary" >submitotp</button>
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
         </form>
          </div>
        </div>  
      </div>

</body>
</html>
<script type="text/javascript">
  $(function () {
        $("a[class='Update']").click(function () {
            $("#modal").modal("show");
            document.getElementById('submitotp').style.visibility = "hidden";
            return false;
        });
    });
    
  

 


  
function myfunction()
{
    function validatePhoneNumber(input_str) {
    var re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;

    return re.test(input_str);
}

    var phone = document.getElementById('phoneno1').value;
    
    if (!validatePhoneNumber(phone)) {
        
        document.getElementById('phone_error').classList.remove('hidden');
        $("#otp").attr("type", "hidden");
        document.getElementById('submitotp').style.visibility = "hidden";
        document.getElementById('generateotp').style.visibility = "visible";

    }
   
     else {
        document.getElementById('phone_error').classList.add('hidden');
        document.getElementById('phone_success').classList.remove('hidden');
        $("#otp").attr("type", "text"); 
        document.getElementById('submitotp').style.visibility = "visible";
        document.getElementById('generateotp').style.visibility = "hidden";
        document.getElementById('phoneno1').readOnly = true;

    
    }
   
    event.preventDefault();
}

// document.getElementById('myform').addEventListener('submit', validateForm);

 


$(function () {
        $("a[class='change']").click(function () {
            $("#otp").attr("type", "hidden");
            document.getElementById('phoneno1').readOnly = false;
            document.getElementById('generateotp').style.visibility = "visible";    
            document.getElementById('submitotp').style.visibility = "hidden";
            document.getElementById('phone_success').classList.add('hidden');
            document.getElementById('phone_error').classList.add('hidden');
            return false;
        });
    });

//     $(function(){
//     $("#submitotp").click(function(){
      
//         var mobile= $("#phoneno1").val();
        
//         var token = $("#csrf").val();
//        $.ajax({
//         url:'/otpvalid',
//         type:'POST',
//         data:{
//             _token:token,
            
//             mobile:mobile,
           
//         },
//         success:function(result){
//             var result = JSON.parse(result);
//             // alert(result);
//             if(result.statusCode == 200){
//                     $("#formdiv").removeClass('show');
//                     $("#formdiv").addClass('hide');
//                     $("#otpdiv").removeClass('hide'); 
//                     $("#otpdiv").addClass('show'); 
//                     }
//             else{
//                 alert("something wrong... please try later");
//             }
//         }
//        })
//     })

    $("#generateotp").click(function(){
        var phoneno = $("#phoneno1").val();
      
        var token = $("#csrf").val();
     
        $.ajax({
            type:"post",
            url:'/sendotp',
            data:{
               _token:token,
                phoneno:phoneno
            },
            success:function(otpResult){
               
            }
        })
    })

</script>
<?php /**PATH /home/szigony/project1/resources/views/products/form.blade.php ENDPATH**/ ?>