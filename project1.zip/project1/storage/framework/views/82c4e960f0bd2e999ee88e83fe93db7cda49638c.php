<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <link href="https://unpkg.com/bootstrap-table@1.18.3/dist/bootstrap-table.min.css" rel="stylesheet">
    <link
        href="https://unpkg.com/bootstrap-table@1.18.3/dist/extensions/page-jump-to/bootstrap-table-page-jump-to.min.css"
        rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
    <script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js" defer></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src="https://markcell.github.io/jquery-tabledit/assets/js/tabledit.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/bootstrap-table@1.18.3/dist/bootstrap-table.min.js"></script>
    <script src="https://unpkg.com/bootstrap-table@1.18.3/dist/extensions/print/bootstrap-table-print.min.js"></script>

</head>

<body>
    <div class="container">
        <div class="alert alert-success" id="success" style="display:none"></div>
        <div class="alert alert-danger" id="danger" style="display:none"></div>
        <h3 style="text-align:center">Table Edit Delete with jhQuery in Laravel</h3>
        <br />
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title" style="text-align:center">User Data</h3>
            </div>
            <div class="panel-body">
                <button type="button" class="btn btn-primary" onclick="window.location='<?php echo e(url('/create')); ?>'" style="
              margin-left: 1000px;
          ">Create</button>
                <div class="table-responsive">
                    <table class="table" id="mytable" data-editable-emptytext="Default empty text."
                        data-editable-url="/my/editable/update/path" data-show-print="true" data-show-columns="true"
                        data-page-list=[3,6,9] data-pagination="true" data-search="true" data-show-jump-to="true">
                        <thead class="thead-dark">

                            <tr>
                                <th scope="col" data-halign="center" data-align="center" data-searchable="false">Id</th>
                                <th scope="col" data-halign="center" data-field="user_image" data-sortable="true"
                                    data-align="center" data-searchable="false">Image</th>
                                <th scope="col" data-field="name" data-halign="center" data-align="center"
                                    data-sortable="true">Name</th>
                                <th scope="col" data-field="email" data-halign="center" data-align="center"
                                    data-sortable="true">Email</th>
                                <th scope="col" data-halign="center" data-align="center" data-searchable="false">Tools
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($row->id); ?></td>
                                    <?php if($row->user_image == null): ?>
                                        <td style="height: 77px;width: 76px; ">
                                            <img src="https://img.icons8.com/officel/80/000000/edit-user-male.png"
                                                class="img-circle" style="width: 50px" />
                                        </td>
                                    <?php else: ?>
                                        <td style="height: 77px;width: 76px;">
                                            <img src="images/<?php echo e($row->user_image); ?>" class="img-circle"
                                                style="width: 50px;border-radius: 100%;height: 50px;"></img>
                                        </td>
                                    <?php endif; ?>
                                    <td><?php echo e($row->name); ?></td>
                                    <td data-editable="true"><?php echo e($row->email); ?></td>

                                    <td>
                                        <div class="col-sm-12">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="btn btn-primary" data-toggle="modal"
                                                        data-category="edit" data-target="#exampleModal"
                                                        data-whatever1="<?php echo e($row->name); ?>"
                                                        data-whatever2="<?php echo e($row->email); ?>"
                                                        data-whatever3="<?php echo e($row->password); ?>"
                                                        data-whatever4="<?php echo e($row->id); ?>"
                                                        data-whatever5="images/<?php echo e($row->user_image); ?>"
                                                        data-whatever6="<?php echo e($row->tid); ?>"><i
                                                            class="fa fa-pencil" aria-hidden="true"></i>Edit
                                                    </div>
                                                </div>
                                                <div class="com-sm-6">
                                                    <div class="btn btn-danger" id="Delete"
                                                        onclick="myfunction('<?php echo e($row->id); ?>')">Delete</div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
                        
    <div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <label class="modal-title" for="exampleInputEmail1" id="exampleModalLabel"
                        style="padding-left: 250px;">User Edit</label>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="body">
                    <form id="imageupload" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div id="kv-avatar-errors-2" class="center-block" style="width:800px;display:none"></div>
                        <div class="row">
                            <div class="col-sm-4 text-center">
                                <div class="kv-avatar">
                                    <div class="file-loading">

                                        <input name="image" type="file" id="image" style="display: none">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 mb-2">

                            <img id="preview-image-before-upload" src=""
                                style="width: 110px;margin-left: 200px;border-radius: 100%;height: 100px;"
                                data-def-dd="pic" name="preview-image-before-upload" alt="preview image"
                                style="max-height: 250px;">



                        </div>
                        <div class="form-group">
                            <label for="exampleInputId" class="form-control-label"></label>
                            <input type="hidden" name="id" class="form-control id" id="id1" placeholder="ID">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputName" class="form-control-label">Name</label>
                            <input type="text" name="name" class="form-control name" id="name" placeholder="Name">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail" class="form-control-label">Email address</label>
                            <input type="email" name="email" class="form-control email" id="email"
                                aria-describedby="emailHelp" placeholder="email">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPassword" class="form-control-label">Password</label>
                            <input type="text" name="password" class="form-control password" id="password"
                                placeholder="Password">
                        </div>
                

                        <div class="form-group">
                            <label for="exampleFormControlSelect1">task</label>
                            <select class="form-control" name="task" id="task"  >
                            
                                
                          
                                <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?> </option>
                            
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                               
                            </select>
                        </div>

                       


                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button class="btn btn-success" id="ajaxsubmit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
                 
   
</body>

</html>

<script type="text/javascript">

$('#ajaxsubmit').submit(function () {

// Get the Login Name value and trim it
var name = $.trim($('#name').val());

// Check if empty of not
if (name  === '') {
    alert('Text-field is empty.');
    return false;
}
});

    $(function() {

        $('#mytable').bootstrapTable()

        $('#datatable').DataTable({
            "pageLength": 5
        })


    });




    // display row data in input fields
    $(document).ready(function() {
        $('#exampleModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var Id = button.data('whatever4')
            var Name = button.data('whatever1')
            var Email = button.data('whatever2')
            var Password = button.data('whatever3')
            var Image = button.data('whatever5')
            var Task = button.data('whatever6')

            var image1 = "https://img.icons8.com/officel/80/000000/edit-user-male.png"

            
            var modal = $(this)
            modal.find('.id').val(Id)
       
            modal.find('.name').val(Name)
          
            modal.find('.email').val(Email)
            
            modal.find('.password').val(Password)
            modal.find('#task').val(Task)

            if (Image == "images/") {
                $("#preview-image-before-upload").attr('src', image1);
            } else {
                $("#preview-image-before-upload").attr('src', Image);
            }


           
        })
    });


    //edit function
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        }
    });
    jQuery('#imageupload').on('submit', function(e) {

        var formData = new FormData(this);
        e.preventDefault();


        jQuery.ajax({
            url: "<?php echo e(url('/action')); ?>",
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(result) {
                setTimeout(function() {
                    window.location.replace('tabledit');
                    jQuery("#body").load("#mytable");
                }, 100);
                jQuery('#success').show();
                jQuery('#success').html(result.success);
            }
        });
    });



    //delete
    function myfunction(id) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        jQuery.ajax({
            url: "<?php echo e(url('/delete')); ?>",
            method: 'POST',
            data: {

                id: id
            },
            success: function(result) {


                setTimeout(function() {
                    window.location.replace('tabledit')
                    $("#body").load("#mytable");
                }, 100);
                jQuery('#danger').show();
                jQuery('#danger').html(result.delete);

            }

        });
    }
    // model hide function

    $(".btn btn-success").click(function() {
        setTimeout(function() {
            $("#ajaxsubmit").modal('hide');
        }, 100);
    });


    // image preview function
    $(document).ready(function(e) {
        $('#image').change(function() {
            let reader = new FileReader();
            reader.onload = (e) => {
                $('#preview-image-before-upload').attr('src', e.target.result);
            }
            reader.readAsDataURL(this.files[0]);

        });

    });


    var loadFile = function(event) {
        var image = document.getElementById('output');
        image.src = URL.createObjectURL(event.target.files[0]);
    };

    // image upload
    $(function() {
        var fileupload = $("#image");
        var image = $("#preview-image-before-upload");
        image.click(function() {
            fileupload.click();
        });
        fileupload.change(function() {
            var fileName = $(this).val().split('\\')[$(this).val().split('\\').length - 1];

        });
    });
</script>
<?php /**PATH /home/szigony/project1/resources/views/products/index.blade.php ENDPATH**/ ?>