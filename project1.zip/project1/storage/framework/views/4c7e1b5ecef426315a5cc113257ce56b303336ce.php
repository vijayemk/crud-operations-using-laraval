 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>User Registration </h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('products.create')); ?>"> Create New Product</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Password</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->email); ?></td>
            <td><?php echo e($product->password); ?></td>
         
            <td>

                <form action="<?php echo e(route('products.destroy',$product->id)); ?>" method="POST">
   
                 
                    <div class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" ><i class="fa fa-pencil" aria-hidden="true"></i>Edit
                    </div>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
      
    </table>
  
  
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-id="<?php echo e($product->id); ?>" data-whatever1=<?php echo e($product->name); ?> data-whatever2=<?php echo e($product->email); ?> data-whatever3=<?php echo e($product->password); ?> aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <label class="modal-title" for="exampleInputEmail1"  id="exampleModalLabel">User Edit</label>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
               
                
                <form action="<?php echo e(route('products.update',$product->id)); ?>" method="POST">
                   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                     <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Name:</strong>
                                <input type="text" name="name" value="<?php echo e($product->email); ?>"  class="form-control" placeholder="Name">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Email:</strong>
                                <input type="text" name="email" value="<?php echo e($product->email); ?>" class="form-control" placeholder="Email">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Password:</strong>
                                <input type="text" name="password" value="<?php echo e($product->password); ?>" class="form-control" placeholder="Password">
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                          <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
               
                </form>
              
            
          </div>
        </div>
      </div>
      <?php echo $products->links(); ?>

<?php $__env->stopSection(); ?>
<script>
$('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var id = button.data('whatever') // Extract info from data-* attributes
  var Name = button.data('whatever1') 
  var Email = button.data('whatever2')
  var Password = button.data('whatever3')
  var password = button.data('whatever')// Extract info from data-* attributeswhateverew
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + Name)
  // modal.find('.modal-body input').val(recipient)
  modal.find('.name').val(Name)
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + Email)
  // modal.find('.modal-body input').val(recipient)
  modal.find('.email').val(Email)
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + Password)
  // modal.find('.modal-body input').val(recipient)
  modal.find('.password').val(Password)
})
</script>
<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/szigony/project1/resources/views/products/index1.blade.php ENDPATH**/ ?>