<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Response;
use Validator;
use Illuminate\View\Middleware\ShareErrorsFromSession;
use Illuminate\Support\MessageBag;
use App\Images;
use Image;
use Redirect;
use Exception;

class TableditController extends Controller
{
	function search(Request $request)
	{
		$q = $request->search;
		$user = DB::table('forms')
		->where('name','LIKE','%'.$q.'%')->orWhere('email','LIKE','%'.$q.'%')->get();
		if(count($user) > 0)
		{
			return view('welcome')->withDetails($user)->withQuery ( $q );
		}
		else 
		{
			return view ('welcome')->withMessage('No Details found. Try to search again !');
	    }
	}
    function index()
    {
		$task = DB::table('Task')
		->get();
	
	

    	$data = DB::table('forms')
		->where('isDeleted',0)
		->LeftJoin('map', 'forms.id', '=', 'map.uid')
		->get();

	
		
    	return view('products/index', compact('data','task'));
    }
	function create()
	{
		return view('products/form');
	}
   
 
 function actions(Request $request)
    {  
		
       
		if($request->ajax())
		{

			

			$map = DB::table('map')
		    ->where('uid',$request->id)
		    ->get();
         
		$s=	sizeof($map);
		
		  if($s == 0)
      
		     {
				$map1=array(
					'uid' => $request->id,
					'tid' => $request->task,
					);
		
					DB::table('map')
					->insert($map1);
				
			
		     }
			else
			{
				
           $map2=array(

			   
			   'tid' => $request->task,
		   );
				DB::table('map')
				    ->where('uid',$request->id)
					->update($map2);   

    	     }
			
          
	    
		    $imageName = $request->id.'.'.$request->image->extension();  
     
			$request->image->move(public_path('images'), $imageName);
			$data = array(
    				'name'	=>	$request->name ,
    				'email'		=>	$request->email,
    				'password'		=>	$request->password,
					'user_image'         => $imageName,
					
					
    			);
				DB::table('forms')
			     	->where('id', $request->id )
    				->update($data);
			
					
					return response()->json(['success'=>'Data is updated successfully']);
		
		
            
        }
	}
	function delete(Request $request)
    {  
    	if($request->ajax())
    	{ 
			

		  
			DB::table('forms')
			->where('id', $request->id)
			->update( [ 'isDeleted' => 1 ]);
		
    		
	     	return response()->json(['delete'=>'Data is deleted successfully']);
    	}
    }	

	function register(Request $request)
	{
       

	   $data2 = $request->validate([
		'name' => 'required',
		'email' => 'required|email|unique:forms|email:rfc,dns',
		'password' => 'required',
		'address1' => 'required',
		'address2' => 'required',
		'address3' => 'required',
		'pincode'  => 'required||digits:6|integer',
		'phoneno'  => 'required||digits:10|integer',
        'password' => 'required|between:6,12',
	]);
     
	$data1 = array(
		'Values' =>	array('name'	=>	$request->name ,'email' => $request->email,'phoneno' => $request->phoneno, 'address'=> array('address1'		=>	$request->address1,'address2'		=>	$request->address2,'address3'		=>	$request->address3), 'password'		=>	$request->password,'pincode'		=>	$request->pincode,),
			
		);	

	$data = array(
		'name'	=>	$request->name ,
		'email'		=>	$request->email,
		'password'		=>	$request->password,
		'address1'		=>	$request->address1,
		'address2'		=>	$request->address2,
		'address3'		=>	$request->address3,
		'pincode'		=>	$request->pincode,
		'phoneno'		=>	$request->phoneno,
		'json_data'     => json_encode( $data1),
		
	);
	DB::table('forms')
	->insert($data);

	return redirect()->back()->with('message', 'login successfully');


	//    $vsli = Validator::make($request->all(),['name' => 'required']);
	// 	if($vsli->fails()){
	// 		return response()->json(['errors'=>$vsli->errors()],422);
	// 	} 
	// 		return redirect('/create')->withErrors($vsli);

		// return Redirect::back()->withErrors(['msg' => 'The Message']);
		// return redirect('/register')
		// ->withErrors($validator)
		//     ->withInput();
		// if($request->ajax())
    	// {  
			
			 
			
			
			
		
					
					
					
    			
   
				
				
			
			
		// 		DB::table('forms')
		// 		->insert($data);

				
		// 			return response()->json(['success'=>'Data is updated successfully']);
		// 			return response()->json(['success'=>'Data is updated successfully']);
		
		
        //       }
	}
	
	function generateOTP(){
        $otp = mt_rand(1000,9999);
        return $otp;
    }
    function sendotp(Request $request){
    
		try {
  
            $basic  = new \Nexmo\Client\Credentials\Basic("b440a891", "RwqHjQhVaSSf6jFK");
            $client = new \Nexmo\Client($basic);
			$otp = mt_rand(9999,100000);
            $receiverNumber = "91".$request->phoneno;
		
            $message = "Welcome to ecommerce.com.Your otp is  $otp.Thank you using for services";
		    
  
            $message = $client->message()->send([
			
				'to' => $receiverNumber,
                'from' => 'Vonage APIs',
                'text' => $message
            ]);	
             
			$data=array(
				'otp' => $otp,
			);
			DB::table('forms')
			->where('phoneno', $request->phoneno)
			->update($data );
			
            dd('SMS Sent Successfully.');
		
		
        } catch (Exception $e) {
            dd("Error: ". $e->getMessage());
        }

	}

    function submitotp(Request $request){

		
		$otp1 = DB::table('forms')
		    ->where('phoneno',$request->phoneno1)
		    ->get('otp');
		

	}

}


	

