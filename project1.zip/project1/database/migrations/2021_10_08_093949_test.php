<?php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class Test extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {


        $table = DB::table('forms') 
       -> whereJsonContains('json_data->Values->name', ['vijay'])->get();
          
        
        
      dd($table);


   
         $address2= $table[0]->address2;

        $json_data1= $table[0]->json_data;
     

         $json_data=json_decode($json_data1);
        
    

         
         dd($s);

        $table = DB::table('forms') ->pluck('id')->toArray();
        $count=count($table);
      
    //    $s= in_array("12", $table);
    //     dd($table);
        for($i=0;$i<=$count-1;$i++)
        {
            $table = DB::table('forms') ->get()->toArray();
        
        
        
            //  $id= $table[$i]->id;
       
            //  if (in_array("12", $id))
            //  {
            //  echo "found";
            //  }
            //  else
            //  {
            //   echo "not found";
            //    }
    
    
       
             $address2= $table[$i]->address2;
    
            $json_data1= $table[$i]->json_data;
         
    
             $json_data=json_decode($json_data1);
             
        
             
         $js=$json_data->Values->address->address2;
         
       

         DB::table('forms')
            ->where('id', $id)
             ->update(['json_data->Values->address->address2'=> $address2 ]);

            
        }

    //      $jsdata1= DB::table('forms')
    //      ->get('json_data');
     
     
    //      $jsdata=json_decode($jsdata1);
     
   
    //   $a= $jsdata.Values;

    //     dd($a);
  
      


    // //    DB::table('forms')
    // //    ->where('id',16)
    // //     ->update('name','vijay');
       
    //     // $test=  DB::table('forms')
    //     //   ->where('json_data->Values->address->address2','vijay');
            
    //     //  dd($test);
      
       
       die;
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::dropIfExists('forms');
    }
}
